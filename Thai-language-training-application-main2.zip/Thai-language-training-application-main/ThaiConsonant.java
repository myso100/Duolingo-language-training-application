package thai.language;

public class ThaiConsonant {

    private static final String[] THAI_CONSONANTS = {
        "ก", "ข", "ค", "ฆ", "ง",
        "จ", "ฉ", "ช", "ซ", "ฌ", "ญ",
        "ฎ", "ฏ", "ฐ", "ฑ", "ฒ", "ณ",
        "ด", "ต", "ถ", "ท", "ธ", "น",
        "บ", "ป", "ผ", "พ", "ฟ", "ภ", "ม",
        "ย", "ร", "ล", "ว",
        "ศ", "ษ", "ส", "ห", "ฬ", "อ", "ฮ"
    };

    public static String getRandomConsonant() {
        int index = (int)(Math.random() * THAI_CONSONANTS.length);
        return THAI_CONSONANTS[index];
    }

    // Main method to run the program
    public static void main(String[] args) {
        System.out.println("Random consonant: " + getRandomConsonant());
    }
}
