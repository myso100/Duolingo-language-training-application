# Thai-language-training-application
[School Project] name should be obvious, what it does. 
